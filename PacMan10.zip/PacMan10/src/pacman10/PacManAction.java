package pacman10;
//Hakeem Sibai

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class PacManAction extends PecManEssential implements KeyListener {

    String Start;
    int Right;
    int Lift;
    int Up;
    int Down;
    boolean key_right, key_left, key_down, key_up;

    public PacManAction() {
    }

    public PacManAction(String Start, int Right, int Lift, int Up, int Down) {
        this.Start = Start;
        this.Right = Right;
        this.Lift = Lift;
        this.Up = Up;
        this.Down = Down;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            System.out.println("Left");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void keyPressed(int VK_LEFT) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
