package pacman10;
  //Hakeem Siba



public class PacMan10 {

    public static void main(String[] args) {
        
        PacManAction p = new PacManAction();
        
    }

}
