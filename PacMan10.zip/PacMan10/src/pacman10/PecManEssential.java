package pacman10;
//Hakeem Sibai

public class PecManEssential {

    String grid[][] = new String[3][3];

    public PecManEssential() {
    }

    

    public void initGrid() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                this.grid[i][j] = "*";
            }

        }
    }

    public void printGrid() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                System.out.print("| ");
                System.out.print(this.grid[i][j]);
                System.out.print(" |");
            }
            System.out.println();

        }
    }

    public void position(int x, int y) {
        this.grid[x][y] = "G";

    }

}
